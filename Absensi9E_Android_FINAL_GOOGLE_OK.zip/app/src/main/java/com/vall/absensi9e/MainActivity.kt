package com.vall.absensi9e

import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.gms.common.SignInButton
import com.google.android.gms.tasks.Tasks
import com.google.firebase.Timestamp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.TimeZone

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var credentialManager: CredentialManager
    private val adminEmail = "9eakount12@gmail.com"
    private val fixedQr = "VALL-ABSENSI-9E-FIXED"

    private lateinit var loginPanel: LinearLayout
    private lateinit var profilePanel: LinearLayout
    private lateinit var studentPanel: LinearLayout
    private lateinit var adminPanel: LinearLayout
    private lateinit var logoutButton: Button
    private lateinit var welcome: TextView
    private lateinit var studentInfo: TextView
    private lateinit var studentStatus: TextView
    private lateinit var adminOutput: TextView
    private lateinit var nameInput: EditText
    private lateinit var numberInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()
        credentialManager = CredentialManager.create(this)
        bindViews()
        findViewById<Button>(R.id.googleButton).setOnClickListener { googleLogin() }
        findViewById<Button>(R.id.emailLoginButton).setOnClickListener { emailLogin() }
        findViewById<Button>(R.id.saveProfile).setOnClickListener { saveProfile() }
        findViewById<Button>(R.id.scanButton).setOnClickListener { scanQr() }
        findViewById<Button>(R.id.todayButton).setOnClickListener { loadToday() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { loadHistory() }
        logoutButton.setOnClickListener { auth.signOut(); showLogin() }
        refresh()
    }

    private fun bindViews() {
        loginPanel=findViewById(R.id.loginPanel); profilePanel=findViewById(R.id.profilePanel)
        studentPanel=findViewById(R.id.studentPanel); adminPanel=findViewById(R.id.adminPanel)
        logoutButton=findViewById(R.id.logoutButton); welcome=findViewById(R.id.welcome)
        studentInfo=findViewById(R.id.studentInfo); studentStatus=findViewById(R.id.studentStatus)
        adminOutput=findViewById(R.id.adminOutput); nameInput=findViewById(R.id.name); numberInput=findViewById(R.id.number)
    }

    private fun showOnly(v: LinearLayout?) {
        listOf(loginPanel, profilePanel, studentPanel, adminPanel).forEach { it.visibility = if (it == v) android.view.View.VISIBLE else android.view.View.GONE }
        logoutButton.visibility = if (v == loginPanel) android.view.View.GONE else android.view.View.VISIBLE
    }
    private fun showLogin(){ showOnly(loginPanel) }

    private fun refresh() {
        val user=auth.currentUser ?: run { showLogin(); return }
        if(user.email.equals(adminEmail,true)) { showOnly(adminPanel); welcome.text="Admin: ${user.email}"; return }
        db.collection("users").document(user.uid).get().addOnSuccessListener { doc ->
            if(doc.exists()) {
                showOnly(studentPanel)
                val n=doc.getLong("number")?.toInt() ?: 0
                val nm=doc.getString("name") ?: ""
                studentInfo.text="Nama: $nm\nNo. Absen: $n\nEmail: ${user.email}"
                checkToday()
            } else {
                showOnly(profilePanel); welcome.text="Selamat datang, ${user.displayName ?: user.email}"; nameInput.setText(user.displayName ?: "")
            }
        }.addOnFailureListener { toast(it.message ?: "Gagal membaca profil") }
    }

    private fun googleLogin() {
        val clientId = try { getString(resources.getIdentifier("default_web_client_id","string",packageName)) } catch (_:Exception){ "" }
        if(clientId.isBlank()) { toast("Aktifkan Google Login di Firebase lalu download ulang google-services.json"); return }
        val option=GetGoogleIdOption.Builder().setServerClientId(clientId).setFilterByAuthorizedAccounts(false).setAutoSelectEnabled(false).build()
        val request=GetCredentialRequest.Builder().addCredentialOption(option).build()
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val result=credentialManager.getCredential(this@MainActivity, request)
                val cred=GoogleIdTokenCredential.createFrom(result.credential.data)
                val firebaseCred=GoogleAuthProvider.getCredential(cred.idToken,null)
                auth.signInWithCredential(firebaseCred).addOnSuccessListener { refresh() }.addOnFailureListener { toast(it.message ?: "Login Google gagal") }
            } catch(e:GetCredentialException){ toast(e.message ?: "Login Google dibatalkan") }
        }
    }

    private fun emailLogin() {
        val email=findViewById<EditText>(R.id.email).text.toString().trim(); val pass=findViewById<EditText>(R.id.password).text.toString()
        if(email.isBlank()||pass.length<6){ toast("Isi email dan password minimal 6 karakter"); return }
        auth.signInWithEmailAndPassword(email,pass).addOnSuccessListener { refresh() }.addOnFailureListener {
            // For first-time admin/email users, allow account creation; identity is still protected by Firestore rules.
            auth.createUserWithEmailAndPassword(email,pass).addOnSuccessListener { refresh() }.addOnFailureListener { e -> toast(e.message ?: "Login gagal") }
        }
    }

    private fun saveProfile() {
        val u=auth.currentUser ?: return
        val name=nameInput.text.toString().trim(); val number=numberInput.text.toString().toIntOrNull()
        if(name.length<2 || number==null || number !in 1..30){ toast("Nama dan nomor absen 1-30 wajib diisi"); return }
        val userRef=db.collection("users").document(u.uid); val numRef=db.collection("studentNumbers").document(number.toString())
        val profile=hashMapOf<String,Any>("uid" to u.uid,"name" to name,"number" to number,"email" to (u.email ?: ""),"role" to "student")
        val lock=hashMapOf<String,Any>("uid" to u.uid,"number" to number)
        db.runTransaction { tx ->
            if(tx.get(numRef).exists()) throw IllegalStateException("Nomor absen sudah dipakai")
            tx.set(numRef,lock); tx.set(userRef,profile)
        }.addOnSuccessListener { refresh() }.addOnFailureListener { toast(it.message ?: "Gagal menyimpan identitas") }
    }

    private fun dayId(): Long { val cal=Calendar.getInstance(TimeZone.getTimeZone("Asia/Jakarta")); return cal.timeInMillis/86400000L }

    private fun scanQr() {
        val opts=GmsBarcodeScannerOptions.Builder().enableAutoZoom().build(); val scanner=GmsBarcodeScanning.getClient(this,opts)
        scanner.startScan().addOnSuccessListener { barcode ->
            if(barcode.rawValue == fixedQr) recordAttendance() else toast("QR bukan QR Absensi 9E")
        }.addOnCanceledListener { }.addOnFailureListener { toast("Scanner gagal: ${it.message}") }
    }

    private fun recordAttendance() {
        val u=auth.currentUser ?: return; val id=dayId(); val ref=db.collection("users").document(u.uid); val att=db.collection("attendance").document(id.toString()).collection("records").document(u.uid)
        db.runTransaction { tx ->
            val p=tx.get(ref)
            if(!p.exists()) throw IllegalStateException("Profil siswa belum lengkap")
            if(tx.get(att).exists()) throw IllegalStateException("Kamu sudah absen hari ini")
            val data=hashMapOf<String,Any>("uid" to u.uid,"name" to (p.getString("name") ?: ""),"number" to (p.getLong("number")?.toInt() ?: 0),"email" to (p.getString("email") ?: ""),"status" to "HADIR","qrCode" to fixedQr,"dayId" to id,"serverTime" to FieldValue.serverTimestamp())
            tx.set(att,data)
        }.addOnSuccessListener { studentStatus.text="✅ HADIR\nAbsensi berhasil tersimpan." }.addOnFailureListener { studentStatus.text="❌ ${it.message}" }
    }

    private fun checkToday(){ val u=auth.currentUser ?: return; val ref=db.collection("attendance").document(dayId().toString()).collection("records").document(u.uid); ref.get().addOnSuccessListener { studentStatus.text=if(it.exists()) "✅ HADIR\nSudah tercatat hari ini." else "Belum absen hari ini." } }

    private fun loadToday(){
        val id=dayId(); db.collection("attendance").document(id.toString()).collection("records").get().addOnSuccessListener { snap ->
            val s=StringBuilder("ABSENSI HARI INI\n\n"); if(snap.isEmpty)s.append("Belum ada siswa yang absen.\n") else snap.documents.sortedBy{it.getLong("number") ?: 999}.forEach { d -> s.append("${d.getLong("number") ?: "-"}. ${d.getString("name") ?: "-"} — ${d.getString("status") ?: "-"}\n") }; adminOutput.text=s.toString()
        }.addOnFailureListener { toast(it.message ?: "Gagal memuat") }
    }

    private fun loadHistory(){
        db.collectionGroup("records").get().addOnSuccessListener { snap ->
            val s=StringBuilder("RIWAYAT ABSENSI\n\n"); if(snap.isEmpty)s.append("Belum ada riwayat.\n") else snap.documents.sortedWith(compareByDescending<Any>{ (it as com.google.firebase.firestore.QueryDocumentSnapshot).reference.parent.parent?.id ?: "" }.thenBy{ (it as com.google.firebase.firestore.QueryDocumentSnapshot).getLong("number") ?: 999 }).forEach { d -> val parent=d.reference.parent.parent?.id ?: "?"; s.append("HariID $parent — ${d.getLong("number") ?: "-"}. ${d.getString("name") ?: "-"}\n") }; adminOutput.text=s.toString()
        }.addOnFailureListener { toast(it.message ?: "Riwayat gagal dimuat") }
    }

    private fun toast(s:String){ Toast.makeText(this,s,Toast.LENGTH_LONG).show() }
}
