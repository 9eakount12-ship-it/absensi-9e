# Absensi 9E — Final Source

Android app: `com.vall.absensi9e`
Firebase: `absensi-9e`
Admin: `9eakount12@gmail.com`

Alur siswa: login → pertama kali isi nama + nomor 1-30 → scan QR tetap → langsung tercatat HADIR.

Tanpa foto dan tanpa Firebase Storage. Riwayat tersimpan di Firestore. Hari baru ditentukan berdasarkan waktu server +7 jam (WIB).

## Firebase yang harus aktif
- Authentication: Google dan Email/Password
- Firestore Database
- Firestore Rules: gunakan `firestore.rules`

## Penting untuk Google Login
Setelah Google provider diaktifkan, download ulang `google-services.json` dan gantikan file di `app/`, karena konfigurasi OAuth dapat ditambahkan oleh Firebase. Tambahkan SHA-1 aplikasi pada Firebase sebelum menguji Google Sign-In.

## Build
Buka project ini di Android Studio, Sync, lalu Build > Build APK(s).
